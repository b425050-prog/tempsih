# 04 — File Index and Labels

## Application source

| File | Label | Purpose |
|---|---|---|
| `run.pyw` | Desktop launcher | Starts the native application without a console window. |
| `desktop_app.py` | User-interface implementation | Builds the DPI-aware interface, navigation, Model-1 controls, calculations, dialogs, and Data console. |
| `model_1_implementation.py` | Mathematical model implementation | Contains the predictor, ordinary least-squares calibration, partial-pivoting solver, and diagnostics. |
| `offline_database.py` | Offline database implementation | Creates and seeds SQLite, loads coefficients, exposes tables, and saves model runs. |
| `initialize_database.py` | Database reset utility | Creates or restores the local schema and seed records. |
| `build_release.py` | Release builder | Packages the Python application and its local farmer emblem into a standalone Windows folder. |

## Local asset

| File | Label | Purpose |
|---|---|---|
| `assets/farmer-emblem.png` | Agriculture application emblem | Transparent farmer-and-crop artwork used in the title bar and sidebar. |

## Tests

| File | Purpose |
|---|---|
| `tests/test_model_1.py` | Verifies the handbook result, term reconstruction, validation, and coefficient recovery. |
| `tests/test_offline_database.py` | Verifies that all 15 calibration rows exist. |
| `tests/test_display_scaling.py` | Verifies Full HD, 4K, and 8K scale factors. |

## Documentation

| File | Purpose |
|---|---|
| `README.md` | Quick start and project scope. |
| `docs/01_OPERATING_AND_DEMONSTRATION_GUIDE.md` | Complete operating instructions and judge script. |
| `docs/02_MODEL_1_IMPLEMENTATION.md` | Formula, coefficient calibration, validation, and numerical example. |
| `docs/03_OFFLINE_DATABASE.md` | SQLite schema, seed counts, and persistence behavior. |
| `docs/04_FILE_INDEX.md` | This complete file inventory. |

## Generated runtime items

| Item | Purpose |
|---|---|
| `release/KrishiSetu/KrishiSetu.exe` | Standalone application executable. |
| `release/KrishiSetu/data/krishisetu.db` | Local offline database. |
| `release/KrishiSetu/docs/` | Documentation copied beside the executable. |
| `release/KrishiSetu_Offline_Prototype.zip` | Portable archive for transfer to the demonstration computer. |
