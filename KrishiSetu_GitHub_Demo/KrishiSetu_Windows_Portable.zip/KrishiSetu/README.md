# KrishiSetu Model-1 Offline Prototype

This folder contains a native, fully offline Python desktop prototype for the handbook’s Model-1 fair mandi price predictor.

## Quick start

- Packaged application: open `release/KrishiSetu/KrishiSetu.exe`.
- Source launch: run `run.pyw` with Python 3 and Tkinter.
- Local database: `data/krishisetu.db` is created automatically.

## Documentation

1. `docs/01_OPERATING_AND_DEMONSTRATION_GUIDE.md`
2. `docs/02_MODEL_1_IMPLEMENTATION.md`
3. `docs/03_OFFLINE_DATABASE.md`
4. `docs/04_FILE_INDEX.md`

The interface scales from Full HD through 4K and 8K using native DPI-aware text and resolution-relative dimensions. Only Model-1 is implemented; later product areas display an **Available soon** message.
